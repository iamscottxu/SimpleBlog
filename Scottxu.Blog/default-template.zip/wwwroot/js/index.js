$(function () {
    let loadArticles = function (_this) {
        $.getJSON(getSiteSettings().apiUrl + "GetArticleList",
            {
                sortField: "PublishDate",
                sortDirection: "DESC",
                pageSize: 20,
                pageIndex: _this.pageIndex + 1,
                getText: true
            },
            function (data) {
                if (data.success) {
                    for (article of data.data.list) {
                        _this.articles.push({
                            url: 'article.html?guid=' + article.guid,
                            name: article.name,
                            text: article.text
                        });
                    }
                    _this.pageIndex = data.data.pageInfo.pageIndex;
                    _this.pageCount = data.data.pageInfo.pageCount;
                }
                _this.loadSwitch = true;
            });
    }
    new Vue({
        el: '#articles',
        data: {
            articles: [],
            pageIndex: -1,
            pageCount: 1,
            loadSwitch: false
        },
        beforeCreate: function () {
            loadArticles(this);
        },
        created: function () {
            let _this = this;
            $(window).scroll(function () {
                let scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
                // 判断是否滚动到底部
                if (scrollTop + window.innerHeight >= document.body.offsetHeight
                    && _this.pageCount - 1 > _this.pageIndex && _this.loadSwitch) {
                    _this.loadSwitch = false;
                    loadArticles(_this);
                };
            });
        }
    });
});