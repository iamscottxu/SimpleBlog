$(function () {
    new Vue({
        el: '#article',
        data: {
            name: null,
            userName: null,
            labels: null,
            publishDate: null,
            clickTraffic: null,
            type: {
                url: null,
                name: null
            },
            content: null
        },
        beforeCreate: function () {
            let _this = this;
            $.getJSON("sys/API/GetBaseInfo", { getUserName: true }, function (data) {
                if (data.success) {
                    _this.userName = data.data.userName;
                }
            });
            $.getJSON("sys/API/GetArticle", { articleGuid: getQueryString('guid') }, function (data) {
                if (data.success) {
                    let offset = moment().utcOffset();
                    _this.publishDate = moment.utc(data.data.publishDate).utcOffset(offset).format('YYYY年M月D日 HH:mm');
                    _this.name = data.data.name,
                        _this.clickTraffic = data.data.clickTraffic,
                        _this.content = data.data.content,
                        _this.type.name = data.data.articleType.name,
                        _this.type.url = 'articlelist.html?typeGuid=' + data.data.articleType.guid,
                        _this.labels = new Array();
                    if (data.data.articleLabels != null) for (label of data.data.articleLabels) {
                        _this.labels.push({
                            url: 'articlelist.html?labelGuid=' + label.guid,
                            name: label.name
                        });
                    }
                }
            });
        }
    });
});