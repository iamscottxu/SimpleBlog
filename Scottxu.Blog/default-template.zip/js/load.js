$(function () {
    new Vue({
        el: '#logo',
        data: {
            blogName: null
        },
        beforeCreate: function () {
            let _this = this;
            $.getJSON("sys/API/GetBaseInfo", { getBlogName: true }, function (data) {
                if (data.success) {
                    document.title = $('title').data('title');
                    document.title += _this.blogName = data.data.blogName;
                }
            });
        }
    });
    new Vue({
        el: '#hotArticles',
        data: {
            hotArticles: null
        },
        beforeCreate: function () {
            let _this = this;
            $.getJSON("sys/API/GetArticleList",
                {
                    sortField: "ClickTraffic",
                    sortDirection: "DESC",
                    pageSize: 8
                },
                function (data) {
                    _this.hotArticles = new Array();
                    if (data.success) for (article of data.data.list) {
                        _this.hotArticles.push({
                            url: 'article.html?guid=' + article.guid,
                            name: article.name
                        });
                    };
                });
        }
    });
    new Vue({
        el: '#labels',
        data: {
            labels: null
        },
        beforeCreate: function () {
            let _this = this;
            $.getJSON("sys/API/GetLabelList", function (data) {
                _this.labels = new Array();
                if (data.success) for (label of data.data.list) {
                    _this.labels.push({
                        url: 'articlelist.html?labelGuid=' + label.guid,
                        name: label.name
                    });
                };
            });
        }
    });
    Vue.component('treemenu', {
        template: '#tree_menu_template',
        props: {
            treeitem: Object
        },
        data: function () {
            return {};
        },
        computed: {
            isFolder: function () {
                return this.treeitem.childArticleTypes && this.treeitem.childArticleTypes.length;
            },
            url: function () {
                return 'articlelist.html?typeGuid=' + this.treeitem.guid;
            }
        },
        methods: {

        }
    });
    new Vue({
        el: '#types',
        data: {
            treeItems: null
        },
        beforeCreate: function () {
            let _this = this;
            $.getJSON("sys/API/GetTypeList", function (data) {
                if (data.success) {
                    _this.treeItems = data.data;
                }
            });
        },
        updated: function () {
            $('.tree').treemenu({ delay: 300 }).openActive();
        }
    });
});